<div class="form-group col-8 sell-add-info-price-wrapper">
    <label>@lang('Condition ')</label>
    <select class="form--control" name="condition">
        <option value="">@lang('Select')</option>
        <option value="new">@lang('New')</option>
        <option value="used">@lang('Used')</option>
        <option value="like new">@lang('Like new')</option>
        <option value="reconditon">@lang('Reconditioned')</option>
    </select>
</div>
