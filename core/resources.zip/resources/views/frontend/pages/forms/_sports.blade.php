<div class="form-group col-8 sell-add-info-price-wrapper">
    <label>@lang('Condition ')</label>
    <select class="form--control" name="condition">
        <option value="">@lang('Select')</option>
        <option value="new">@lang('New')</option>
        <option value="used">@lang('Used')</option>
        <option value="like new">@lang('Like new')</option>
        <option value="reconditon">@lang('Reconditioned')</option>
    </select>
</div>
<div class="form-group col-8 sell-add-info-price-wrapper">
    <label>@lang('Type ')</label>
    <select class="form--control" name="sports_type">
        <option value="">@lang('Select')</option>
        <option value="Football">@lang('Football')</option>
        <option value="Cricket">@lang('Cricket')</option>
        <option value="Games & Board Games">@lang('Games & Board Games')</option>
        <option value="Boxing & Martial Arts">@lang('Boxing & Martial Arts')</option>
        <option value="white">@lang('White')</option>
    </select>
</div>
