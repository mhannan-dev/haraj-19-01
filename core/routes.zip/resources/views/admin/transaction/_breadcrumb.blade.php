<div class="dashboard-title-part">
    <h5 class="title">Dashboard</h5>
    <div href="" class="dashboard-path">
        <a href={{ route('admin.dashboard') }}>
            <span class="main-path">Dashboards</span>
        </a>
        <i class="las la-angle-right"></i>
        <a href="{{ route('admin.category.index') }}">
            <span class="active-path g-color">@lang('Advertiser')</span>
        </a>
    </div>

</div>
