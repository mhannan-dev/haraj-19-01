<div class="copyright-wrapper">
    <div class="copyright-area">
        <p>@lang('Copyright') © 2022 <a href="#" class="text--base">Appdevs</a>. All Rights Reserved.</a></p>
    </div>
</div>
