<div class="form-group col-8 sell-add-info-price-wrapper">
    <label>@lang('Condition ')</label>
    <select class="form--control" name="condition">
        <option value="">@lang('Select')</option>
        <option value="new">New</option>
        <option value="used">Used</option>
        <option value="like new">Like new</option>
        <option value="reconditon">Reconditioned</option>
    </select>
</div>
<div class="form-group col-8 sell-add-info-price-wrapper">
    <label>@lang('Type ')</label>
    <select class="form--control" name="sports_type">
        <option value="">@lang('Select')</option>
        <option value="Football">Football</option>
        <option value="Cricket">Cricket</option>
        <option value="Games & Board Games">Games & Board Games</option>
        <option value="Boxing & Martial Arts">Boxing & Martial Arts</option>
        <option value="white">White</option>
    </select>
</div>
