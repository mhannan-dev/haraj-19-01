<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GeneralSetting extends Model
{
    use HasFactory;
    protected $guarded = ['id'];

    protected $casts = ['mail_config' => 'object','sms_config' => 'object'];

    public function scopeSitename($query, $pageTitle)
    {

        $pageTitle = empty($pageTitle) ? '' : ' - ' . $pageTitle;
        return $this->sitename . $pageTitle;
    }

    public function currency()
    {
        return $this->belongsTo(Currency::class,'cur_text','currency_code');
    }
}
