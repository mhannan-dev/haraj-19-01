<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AuthRole extends Model
{
    protected $table = 'auth_roles';
}
