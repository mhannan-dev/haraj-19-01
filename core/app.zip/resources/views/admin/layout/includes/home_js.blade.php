    <!-- BEGIN: Page Vendor JS-->
    <script src="{{asset('/app-assets/vendors/js/charts/chart.min.js')}}"></script>
    <script src="{{asset('/app-assets/vendors/js/charts/raphael-min.js')}}"></script>
    <script src="{{asset('/app-assets/vendors/js/charts/morris.min.js')}}"></script>
    <script src="{{asset('/app-assets/vendors/js/charts/jvector/jquery-jvectormap-2.0.3.min.js')}}"></script>
    <script src="{{asset('/app-assets/vendors/js/charts/jvector/jquery-jvectormap-world-mill.js')}}"></script>
    
    
    <script src="{{asset('/app-assets/vendors/js/charts/chartist.min.js')}}"></script>
    <script src="{{asset('/app-assets/vendors/js/charts/chartist-plugin-tooltip.min.js')}}"></script>  
    <script src="{{asset('/app-assets/js/scripts/pages/dashboard-ecommerce.js')}}"></script>
    <!-- END: Page Vendor JS-->


    @stack('custom_js')
    
    
    