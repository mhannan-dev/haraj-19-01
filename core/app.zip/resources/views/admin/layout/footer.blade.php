<div class="copyright-wrapper">
    <div class="copyright-area">
        <p><a href="#" class="text--base">{{ $general->sitename ? $general->sitename .' - '. $general->site_sub_title : 'AppDevs Solution'   }}</a></p>
    </div>
</div>
